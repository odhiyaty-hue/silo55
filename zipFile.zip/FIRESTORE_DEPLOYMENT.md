# Firestore Security Rules - نشر قواعس الأمان

## 📋 خطوات النشر (الخادم)

### الطريقة 1️⃣: باستخدام Firebase CLI

```bash
# 1️⃣ تثبيت Firebase CLI
npm install -g firebase-tools

# 2️⃣ تسجيل الدخول
firebase login

# 3️⃣ اختيار المشروع
firebase use odhya-e7cca

# 4️⃣ نشر القواعس
firebase deploy --only firestore:rules
```

### الطريقة 2️⃣: باستخدام Firebase Console

1. اذهب إلى: https://console.firebase.google.com/
2. اختر مشروع: `odhya-e7cca`
3. انقر على `Firestore Database` من القائمة اليسرى
4. اضغط على `Rules` في الأعلى
5. انسخ محتوى `firestore.rules` الكامل
6. الصق في Firebase Console
7. اضغط `Publish`

---

## 🔍 فحص القواعس (الاختبار)

```bash
# فتح Firebase Emulator
firebase emulators:start --only firestore

# تشغيل الاختبارات
npm run test:firestore
```

---

## ✅ التحقق من التطبيق

```javascript
// اختبار القراءة (Guest - مجاني)
const sheepRef = collection(db, 'sheep');
const q = query(sheepRef, where('status', '==', 'approved'));
const result = await getDocs(q); // ✅ يعمل

// اختبار الكتابة (محمي)
await setDoc(doc(db, 'sheep', 'new-id'), {...}); // ❌ يفشل بدون تسجيل دخول
```

---

## 🛡️ القواعس الرئيسية:

| المجموعة | Guest | Buyer | Seller | Admin |
|---------|-------|--------|--------|-------|
| **users** | قراءة عامة | كاملة | كاملة | كاملة |
| **sheep** | مقبولة فقط | قراءة | CRUD | كاملة |
| **orders** | ❌ | CRUD | قراءة | كاملة |
| **reviews** | قراءة | CRUD | قراءة | كاملة |
| **favorites** | ❌ | CRUD | CRUD | قراءة |
| **notifications** | ❌ | CRUD | CRUD | CRUD |
| **support** | ❌ | CRUD | CRUD | كاملة |

---

## 🚀 بعد النشر:

1. اختبر Browse Page (Guest Mode) - يجب أن تظهر الأغنام المقبولة فقط ✅
2. اختبر إضافة أغنام (Seller) - يجب أن تحفظ بـ `status: pending` ✅
3. اختبر Admin Dashboard - يجب عرض جميع الأغنام ✅
4. اختبر الطلبات - يجب أن يكون الوصول محدود ✅

---

## ⚠️ ملاحظات مهمة:

- ✅ القواعس تدعم **جميع المنصات** (Web, Mobile, Vercel)
- ✅ القواعس تدعم **وضع الضيف** (Guest Mode بدون تسجيل دخول)
- ✅ القواعس تدعم **جميع الأدوار** (Buyer, Seller, Admin)
- ⚠️ تأكد من نشر القواعس قبل الإطلاق!
- ⚠️ اختبر جميع الحالات في Firebase Console

---

## 📞 الدعم:

إذا حدثت مشاكل:
- تحقق من logs في Firebase Console
- استخدم Firebase Emulator للاختبار المحلي
- تأكد من أن `uid()` في القواعس يطابق معرف المستخدم الفعلي
