# نظرة عامة على نظام أضحيتي

## البنية الكاملة ✅

### 1️⃣ نظام المستخدمين (User System)
- **الأدوار**: Buyer (مشتري) | Seller (بائع) | Admin (إدارة)
- **المصادقة**: Firebase Auth + Google Sign-In
- **الجلسة**: Firebase Persistence (localStorage)
- **الأمان**: Route Guards (ProtectedRoute + PublicRoute)

### 2️⃣ نظام الأغنام (Sheep Management)
```
البائع ➜ إضافة خروف ➜ حالة: PENDING
                   ↓
               Admin يراجع
                ✅/❌
        APPROVED/REJECTED
                ↓
            المشتري يرى (approved فقط)
```

- **الحالات**: pending | approved | rejected
- **سبب الرفض**: rejection reason (عند الرفض)
- **التصفية**: المشتري يرى approved فقط

### 3️⃣ لوحة تحكم الإدارة (Admin Dashboard)
- ✅ مراجعة الأغنام المعلقة (Pending)
- ✅ قبول/رفض مع سبب مفصل
- ✅ عرض جميع الأغنام + المستخدمين + الطلبات
- ✅ إحصائيات شاملة

### 4️⃣ لوحة تحكم البائع (Seller Dashboard)
- ✅ إضافة/تعديل/حذف الأغنام
- ✅ عرض الحالة (pending/approved/rejected)
- ✅ رؤية سبب الرفض على بطاقة الخروف
- ✅ إحصائيات المبيعات

### 5️⃣ تصفح الأغنام (Browse)
- ✅ عرض الأغنام المقبولة فقط
- ✅ فلاتر متقدمة (السعر، العمر، الوزن، المدينة)
- ✅ تفاصيل كاملة لكل خروف

---

## المسارات (Routes) 🛣️

| المسار | الحالة | من يستطيع الوصول |
|------|--------|-----------------|
| `/` | عام | الجميع |
| `/login` | عام | غير المسجلين |
| `/register` | عام | غير المسجلين |
| `/browse` | محمي | Buyers + Admins |
| `/sheep/:id` | محمي | Buyers + Admins |
| `/seller` | محمي | Sellers |
| `/admin` | محمي | Admins |

---

## تعليمات الاستخدام 📖

### لإضافة حساب Admin:
اتبع الخطوات في `ADMIN_SETUP.md`

### للمشتري:
1. انشئ حساب جديد (اختر "مشتري")
2. اذهب إلى صفحة التصفح
3. اختر خروف وأضف طلب

### للبائع:
1. انشئ حساب جديد (اختر "بائع")
2. أضف أغنام من لوحة التحكم
3. انتظر موافقة الإدمن

### للإدمن:
1. سجل دخول باستخدام حساب الإدارة
2. اذهب إلى لوحة التحكم
3. راجع الطلبات المعلقة
4. قبل/ارفض مع سبب

---

## التقنيات المستخدمة 💻

- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Firebase (Auth + Firestore + Storage)
- **Components**: Shadcn UI
- **Routing**: Wouter
- **Forms**: React Hook Form + Zod
- **State**: TanStack React Query + Firebase Persistence

---

## الميزات الأمان 🔒

✅ Firebase Authentication (Email/Password + Google)
✅ Route Guards (Protected + Public routes)
✅ Role-based Access Control (RBAC)
✅ httpOnly Cookies (عند الرفع على الخادم)
✅ Firestore Security Rules (قريباً)

---

## القادم 🚀

- [ ] Firebase Security Rules
- [ ] Real-time Notifications
- [ ] Payment Integration
- [ ] Messaging System
- [ ] User Ratings & Reviews
